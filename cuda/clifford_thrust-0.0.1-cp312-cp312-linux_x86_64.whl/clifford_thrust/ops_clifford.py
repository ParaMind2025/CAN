import torch
import torch.nn as nn

try:
    from . import clifford_backend
    _CUDA_AVAILABLE = True
except ImportError:
    _CUDA_AVAILABLE = False

class CliffordInteractionOp(torch.autograd.Function):
    @staticmethod
    def forward(ctx, z1, z2, shifts, cli_mode_str, ctx_mode_str):
        z1 = z1.contiguous()
        z2 = z2.contiguous()
        
        if not isinstance(shifts, torch.Tensor):
            shifts_tensor = torch.tensor(shifts, dtype=torch.int32, device=z1.device)
        else:
            shifts_tensor = shifts.to(device=z1.device, dtype=torch.int32)
            
        cli_map = {'full': 0, 'wedge': 1, 'inner': 2}
        ctx_map = {'diff': 0, 'abs': 1}
        
        out = clifford_backend.forward(
            z1, z2, shifts_tensor, 
            cli_map[cli_mode_str], ctx_map[ctx_mode_str]
        )
        
        ctx.save_for_backward(z1, z2, shifts_tensor)
        ctx.cli_code = cli_map[cli_mode_str]
        ctx.ctx_code = ctx_map[ctx_mode_str]
        return out

    @staticmethod
    def backward(ctx, grad_out):
        z1, z2, shifts_tensor = ctx.saved_tensors
        grad_out = grad_out.contiguous()
        
        grad_z1, grad_z2 = clifford_backend.backward(
            grad_out, z1, z2, shifts_tensor, ctx.cli_code, ctx.ctx_code
        )
        return grad_z1, grad_z2, None, None, None

class CliffordInteraction(nn.Module):
    """
    [Clifford_Thrust] Accelerated Clifford Interaction.
    Fused Roll+Mul+Sub+Act operations.
    """
    def __init__(self, dim, cli_mode='full', ctx_mode='diff', shifts=[1, 2]):
        super().__init__()
        self.dim = dim
        self.cli_mode = cli_mode  
        self.ctx_mode = ctx_mode 
        self.shifts = shifts 
        self.shifts = [s for s in self.shifts if s < dim]
        
        self.branch_dim = dim * len(self.shifts)
        cat_dim = self.branch_dim * 2 if self.cli_mode == 'full' else self.branch_dim
        self.proj_ = nn.Conv2d(cat_dim, dim, kernel_size=1)    

    def forward(self, z1, z2):
        if _CUDA_AVAILABLE and z1.is_cuda:
            x_ = CliffordInteractionOp.apply(z1, z2, self.shifts, self.cli_mode, self.ctx_mode)
        else:
            # Fallback Logic (Keep your native implementation here)
            if self.ctx_mode == 'diff': C = z2 - z1  
            elif self.ctx_mode == 'abs': C = z2
            feats = []
            for s in self.shifts:
                C_shifted = torch.roll(C, shifts=s, dims=1)
                if self.cli_mode in ['wedge', 'full']:
                    z1_shifted = torch.roll(z1, shifts=s, dims=1)
                    feats.append(z1 * C_shifted - C * z1_shifted)
                if self.cli_mode in ['inner', 'full']:
                    feats.append(z1 * C_shifted * torch.sigmoid(z1 * C_shifted))
            x_ = torch.cat(feats, dim=1)
            
        return self.proj_(x_)