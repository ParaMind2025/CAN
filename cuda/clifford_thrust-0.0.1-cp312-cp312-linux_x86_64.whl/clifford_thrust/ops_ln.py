import torch
import torch.nn as nn

try:
    from . import ln_backend
    _CUDA_AVAILABLE = True
except ImportError as e:
    _CUDA_AVAILABLE = False
    
class FastLayerNorm2dFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight, bias, eps):
        x = x.contiguous()
                
        if weight.dtype != x.dtype:
            weight = weight.to(dtype=x.dtype)
        if bias.dtype != x.dtype:
            bias = bias.to(dtype=x.dtype)
            
        y, mean, rstd = ln_backend.forward(x, weight, bias, eps)
        ctx.save_for_backward(x, weight, mean, rstd)
        return y

    @staticmethod
    def backward(ctx, grad_output):
        x, weight, mean, rstd = ctx.saved_tensors
        grad_output = grad_output.contiguous()
        dx, dgamma, dbeta = ln_backend.backward(grad_output, x, weight, mean, rstd)
        return dx, dgamma.to(x.dtype), dbeta.to(x.dtype), None

class LayerNorm2d(nn.Module):
    """
    [Clifford_Thrust] Accelerated LayerNorm2d (BCHW).
    ~4x faster than PyTorch native on RTX 4090.
    """
    def __init__(self, num_channels, eps=1e-6):
        super().__init__()
        self.num_channels = num_channels
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(num_channels))
        self.bias = nn.Parameter(torch.zeros(num_channels))

    def forward(self, x):
        if _CUDA_AVAILABLE and x.is_cuda:
            return FastLayerNorm2dFunction.apply(x, self.weight, self.bias, self.eps)
        else:
            # Fallback
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            return self.weight[:, None, None] * x + self.bias[:, None, None]